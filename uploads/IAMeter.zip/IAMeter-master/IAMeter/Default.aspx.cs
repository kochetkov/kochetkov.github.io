﻿using System;
using System.Net;
using System.Text;

namespace IAMeter
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var parm1 = Request.Params["parm1"];
            const string cond1 = "ZmFsc2U="; // "false" in base64
            Action<string> pvo = Response.Write;

            // False-negative
            // An analyzer that doesn’t interpret the control flow by functional data flows will not report a vulnerability here
            pvo(parm1);

            // If the analyzer requires compiled code, delete this fragment
            #region

            var argument = "harmless value";

            UnknownType.Property1 = parm1;
            UnknownType.Property2 = UnknownType.Property1;
            UnknownType.Property3 = cond1;

            if (UnknownType.Property3 == null)
            {
                argument = UnknownType.Property2;
            }

            // False-positive
            // An analyzer that ignores noncompiled code will report a vulnerability here
            Response.Write(argument);

            #endregion

            // False-positive
            // An analyzer that ignores execution point reachability conditions will report a vulnerability here
            if (cond1 == null) { Response.Write(parm1); }

            // False-positive
            // An analyzer that ignores the semantics of standard filter functions will report a vulnerability here
            Response.Write(WebUtility.HtmlEncode(parm1));

            // False-positive
            // An analyzer that ignores the semantics of nonstandard filter functions will report a vulnerability here
            // (CustomFilter.Filter implements the logic of `s.Replace("<", string.Empty).Replace(">", string.Empty)`)
            Response.Write(CustomFilterLibrary.CustomFilter.Filter(parm1));

            if (Encoding.UTF8.GetString(Convert.FromBase64String(cond1)) == "true")
            {
                // False-positive
                // An analyzer that ignores the semantics of standard encoding functions will report a vulnerability here
                Response.Write(parm1);
            }

            var sum = 0;
            for (var i = 0; i < 10; i++)
            {
                for (var j = 0; j < 15; j++)
                {
                    sum += i + j;
                }
            }
            if (sum != 1725)
            {
                // False-positive
                // An analyzer that approximates or ignores the interpretation of program loops will report a vulnerability here
                Response.Write(parm1);
            }

            var sb = new StringBuilder();
            sb.Append(cond1);
            if (sb.ToString() == "true")
            {
                // False-positive
                // An analyzer that does not interpret the semantics of standard library types will report a vulnerability here
                Response.Write(parm1);
            }
        }
    }
}